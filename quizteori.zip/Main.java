/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package quizpraktikum;

/**
 *
 * @author Henry Lianto
 */
import java.awt.*;
public class Main extends Panel{
    Main(){
        setBackground(Color.BLUE);
    }
    public void paint(Graphics g){
        //body mobil
        g.setColor(new Color(68, 114, 196));
        g.fillRect(100, 250, 380, 110);
        //border body mobil
        g.setColor(new Color(47, 82, 143));
        g.drawRect(100, 250, 380, 110);
        //atap mobil
        g.setColor(new Color(68, 114, 196));
        g.fillRect(100, 150, 215, 100);
        //border atap mobil
        g.setColor(new Color(47, 82, 143));
        g.drawRect(100, 150, 215, 100);
        //Ban Belakang
        g.setColor(Color.RED);
        g.fillOval(125, 300, 130, 130);
        //Border Ban Belakang
        g.setColor(new Color(47, 82, 143));
        g.drawOval(125, 300, 130, 130);
         //Ban depan
        g.setColor(Color.RED);
        g.fillOval(306, 300, 130, 130);
        //Border Ban Depan
        g.setColor(new Color(47, 82, 143));
        g.drawOval(306, 300, 130, 130);
        
    }
    public static void main(String[] args) {
       Frame f = new Frame("Henry Lianto - 51018012");
       Main gp = new Main();
       f.add(gp);
       f.setSize(600,600);
       f.setVisible(true);
    }
}


